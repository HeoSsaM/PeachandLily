import React from 'react'

export const ProductDetail = () => {
  return (
    <div>상품상세페이지</div>
  )
}
